package com.qsi;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("app")
public class Hello {

    @GET
    public String sayHello() {
        return "Hello";
    }
}
