package com.qsi.login;

import java.io.FileOutputStream;
import java.io.InputStream;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

import org.apache.commons.io.IOUtils;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

@Path("login")
public class Login {

    @GET
    public String get() {
        return "<html><body><form method=\"POST\" enctype=\"" + MediaType.MULTIPART_FORM_DATA + "\">"
                + "<input type=\"text\" name=\"user\" />" + "<input type=\"file\" name=\"fileUpload\"/>"
                + "<input type=\"submit\" value=\"Submit\" />" + "</form></body></html>";
    }

    @POST
    // @Consumes(MediaType.MULTIPART_FORM_DATA)
    public String post(@FormDataParam("fileUpload") InputStream file,
            @FormDataParam("fileUpload") FormDataContentDisposition fileDisposition) throws Exception {
        IOUtils.copy(file, new FileOutputStream("out.ini"));
        return "ok";
    }
}
